package com.pkg2;

public interface Testable {

	int a = 10; // public static final int a =10;

	void disp(); // public abstract void disp();

	void print();

}

//by default all method are public and abstract