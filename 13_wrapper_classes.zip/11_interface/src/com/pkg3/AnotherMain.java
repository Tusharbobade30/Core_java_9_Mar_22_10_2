package com.pkg3;

public class AnotherMain {

}
