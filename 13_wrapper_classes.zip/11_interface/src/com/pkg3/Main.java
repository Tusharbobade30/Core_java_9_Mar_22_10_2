package com.pkg3;

import com.pkg1.Circle;
import com.pkg1.MyDate;
import com.pkg1.Rectangle;
import com.pkg1.SalesManager;
import com.pkg1.Shape;
import com.pkg1.Square;
import com.pkg2.Printable;

public final class Main {

	public static void main(String[] args) {
		print(new Rectangle(10, 10));
		printLine();
		
		print(new Square(20));
		printLine();
		
		//print(new Circle(10));
		print(new MyDate());
		printLine();
		
		print(new SalesManager());
	}
	
	public static void print(Printable ob) {
		ob.print();
	}
	
	public static void printLine() {
		System.out.println("______________________________________________________");
	}
	

}
