package com.pkg1;

import com.pkg2.Printable;

public class MyDate  implements Printable{
	
	public void display() {}

	@Override
	public void print() {
		System.out.println("mydate");
		
	}

}
