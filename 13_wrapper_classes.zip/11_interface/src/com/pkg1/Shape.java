package com.pkg1;

public abstract class Shape {

	public abstract double area();
	
	public abstract double perimeter();
	
	public void display() {
		System.out.println(this.getClass().getName());
	}
}


