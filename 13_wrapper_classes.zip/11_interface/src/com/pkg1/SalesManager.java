package com.pkg1;

import com.pkg2.Printable;
import com.pkg2.Testable;

public class SalesManager extends SalesPerson implements Printable,Testable{
	
	private final double FIXED_INCENTIVE = 5000;
	
	public SalesManager() {
		// TODO Auto-generated constructor stub
	}

	public SalesManager(int id, String name, double salary, double sales, double comm) {
		super(id, name, salary, sales, comm);
	}
	
	public double getFIXED_INCENTIVE() {
		return FIXED_INCENTIVE;
	}
	
	@Override
	public double computeNetSalary() {
		// TODO Auto-generated method stub
		return super.computeNetSalary()+FIXED_INCENTIVE;
	}

	@Override
	public void disp() {
		
	}

	@Override
	public void print() {
		System.out.println(toString());
		System.out.println("Net Salary: "+this.computeNetSalary());
		System.out.println("Comm: "+this.getCommission());
		
	}
	

}
