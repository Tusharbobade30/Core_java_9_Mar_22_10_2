package com.pkg1;

public class SalesPerson extends Employee{
	
	private double sales;
	private double comm;
	
	public SalesPerson() {
	}

	public SalesPerson(int id, String name, double salary,double sales, double comm) {
		super(id, name, salary);
		this.sales = sales;
		this.comm = comm;
	}

	public double getSales() {
		return sales;
	}

	public void setSales(double sales) {
		this.sales = sales;
	}

	public double getComm() {
		return comm;
	}

	public void setComm(double comm) {
		this.comm = comm;
	}

	@Override
	public String toString() {
		return  super.toString() + "\nSalesPerson [sales=" + sales + ", comm=" + comm + "]";
	}
	
	@Override
	public double computeNetSalary() {
		return super.computeNetSalary() + getCommission();
	}
	
	public double getCommission() {
		return sales*comm/100;
	}

}


