package com.seed;

public class StringDemo {
	
	public static void main(String[] args) {
		//exp3();
		
		String s1 = "abcde";
		char[] arr = s1.toCharArray();
		System.out.println(arr[4]);
		
		System.out.println(reverseString(s1));
		
		String s2 ="nitin1";
		System.out.println(isPalindrome(s2));
		
	
	}
	
	public static String reverseString(String str) {
		return new StringBuilder(str).reverse().toString();
	}
	
	public static boolean isPalindrome(String str) {
		return str.equalsIgnoreCase(reverseString(str));
	}
	
	public static void exp3() {

		//mutable string class  StringBuffer   and StringBuilder
		StringBuffer sb = new StringBuffer("jack");
		sb.append(" and jill");
		System.out.println(sb);
		
		StringBuilder builder = new StringBuilder("jack");
		builder.append(" and jill");
		System.out.println(sb);
		
		
		
		String str="";
		StringBuilder sb1 = new StringBuilder();
		for(int i=65;i<=90;i++) {
			sb1.append((char)i);
		}
		str = sb1.toString();
		System.out.println(str);
	}
	
	public static void exp2() {
		String str1= "jack";
		String str2 = "jack";
		String str3 = new String("jack");

		
		System.out.println("str1==str2 :  "+(str1==str2));
		System.out.println("str1==str3 :  "+(str1==str3));
		
		str1 = str1.concat("abc");
		
		String str="";
		for(int i=65;i<=90;i++) {
			str =str+(char)i;
		}
		System.out.println(str);
	}
	//"" A AB ABc ABCD ABCDE  
	
	public static void exp1() {
		String str1="jack";
		System.out.println(str1);
		
		str1.concat(" and Jill");
		System.out.println(str1);
		
		str1 = str1.concat(" and Jill");
		System.out.println(str1);
		
	}

}
