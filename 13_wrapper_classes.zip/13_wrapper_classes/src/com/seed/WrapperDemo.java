package com.seed;

import java.math.BigInteger;

public class WrapperDemo {
	
	public static void main(String[] args) {
		exp2();
	}
	
	public static void exp2() {
		Integer iob1 = 10;  //autoboxing
		int x = iob1;  //unboxing
		
		Integer iob2 = 20;  
		
		Integer iob6 = iob1 + iob2;
		
		
		System.out.println(Integer.toBinaryString(100));
		
	}
	
	public static void exp1() {
		System.out.println("Sizee of Int: "+Integer.SIZE);
		System.out.println("Min value: "+Integer.MIN_VALUE);
		
		
		Integer iob = new Integer(10);
		Integer iob1 = Integer.valueOf(10);
		System.out.println(iob==iob1);
		
		Integer iob3 =Integer.valueOf( iob.intValue() + iob1.intValue());
		
		String str1 ="10";
		String str2 = "20";
		String str3 = str1+ str2;
		
		int x = Integer.parseInt(str1);  //string to primitive int
		float f = Float.parseFloat(str1);
		
		Integer iob10 =Integer.valueOf(str1);//string to Integer object
		
		int a =10;
		int b=10;
		int c= a+b;
			
	}

}
