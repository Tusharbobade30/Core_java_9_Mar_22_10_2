package coom.seed;

public class Home {
	
	private String houseNo;
	

    public Home(String houseNo) {
		this.houseNo = houseNo;
	}

    public static class Locker {

		private Integer lockerId;

		public Locker(){
		}

		public Locker(Integer lockerId) {
			this.lockerId = lockerId;
		}

		public void display() {
			System.out.println("locker id: " + lockerId);
			System.out.println("-------------------------------------------");
		}

	}

}
