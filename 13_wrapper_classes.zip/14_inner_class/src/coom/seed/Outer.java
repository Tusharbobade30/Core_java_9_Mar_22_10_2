package coom.seed;

public class Outer {

	public class Inner { // simple inner class

	}

	public class AnotherInner { // simple inner class

	}

	public static class Inner1 { // static inner class

	}
	
	public static class AnotherStaticInner { // simple inner class

	}

	public void disp() {
		class Inner2 { // local inner class

		}

		Outer out = new Outer() { // annoynomous inner class

		};
		
		class A{
			
		}
		
		class B{
			
		}

	}
	
	public void foo() {
		class A{
			
		}
	}

}
