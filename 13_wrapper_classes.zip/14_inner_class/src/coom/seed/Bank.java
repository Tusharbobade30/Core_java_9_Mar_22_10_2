package coom.seed;

public class Bank {

	private Integer bankId;
	int a=1;

	public Bank() {
		// TODO Auto-generated constructor stub
	}

	public Bank(Integer bankId) {
		super();
		this.bankId = bankId;
	}

	public Integer getBankId() {
		return bankId;
	}

	public void setBankId(Integer bankId) {
		this.bankId = bankId;
	}

	public class Locker {

		private Integer lockerId;
		int a =10;

		public Locker(){
		}

		public Locker(Integer lockerId) {
			this.lockerId = lockerId;
		}

		public void display() {
			int a=100;
			System.out.println("bank id: " + bankId);
			System.out.println("locker id: " + lockerId);
			System.out.println("a="+a+"   a="+this.a+"    a="+Bank.this.a);
			System.out.println("-------------------------------------------");
		}

	}

}
