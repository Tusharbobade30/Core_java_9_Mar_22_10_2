package coom.seed;

import java.util.Scanner;

public class Main {
	
	public static void main(String[] args) {
		//simpleInnerClassExp();
		//staticInnerClass();   
		
		
	
		
	}
	
	public static boolean isPrime(int number) {
		
		return true;
	}
	
	
	public static void annoynomousClassDemo() {
		Dog d1 = new Dog();
		final int x=10;
		Dog d2 = new Dog() {
			@Override
			public void bark() {
				System.out.println("bowwwwwwwww");
				System.out.println(x);  //local variable without final is not allowed in the inner class
			}
			
			public void display() {
				
			}
		};
		System.out.println(d1.getClass().getName());
		System.out.println(d2.getClass().getName());
		
		d2.bark();
		
		
		new Dog() {
			@Override
			public void bark() {
				System.out.println("bowwwwwwwww");
			}
			
			public void display() {
				
			}
		}.display();
		
		
	}
	
	public static void staticInnerClass() {
		Home.Locker locker =new Home.Locker(101);
		locker.display();
	}
	
	public static void simpleInnerClassExp() {
		Bank b = new Bank(101);
		Bank.Locker locker = b.new Locker(1001);
		locker.display();
		
		Bank.Locker locker1 = new Bank(102).new Locker(1002);
		locker1.display();
	}
	
	public static void localInnerClassDemo() {
		int a=10;
		class Local{
			
		}
		
		Local ob = new Local();
	}

}
