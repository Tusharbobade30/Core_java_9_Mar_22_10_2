package com.pkg1;

public class Manager extends Employee {
	private int noOfSubordinate;

	public Manager() {
		super();
		//System.out.println("Default manager constructor");
	}

	public Manager(int id,String name, double salary, int noOfSubordinate) {
		super(id,name,salary);
		//System.out.println("Paramterized manager constructor");
		this.noOfSubordinate = noOfSubordinate;
	}

	@Override
	public double computeNetSalary() {
		return super.computeNetSalary()+ getBonus();
		
	}
	
	//special method
	public double getBonus() {
		return noOfSubordinate*200;
	}

	@Override
	public String toString() {
		return super.toString()+ "   Manager [noOfSubordinate=" + noOfSubordinate + "]";
	}
	
	public Manager foo() {
		System.out.println("manager class");
		return null;
	}
	
	
	@Override
	public boolean equals(Object obj) {
		boolean b= super.equals(obj) ;
		if(b) {
			return this.noOfSubordinate == ((Manager)obj).noOfSubordinate;
		}
		return false;
	}


}
