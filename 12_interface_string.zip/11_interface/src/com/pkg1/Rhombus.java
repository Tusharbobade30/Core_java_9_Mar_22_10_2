package com.pkg1;

public class Rhombus {

}
