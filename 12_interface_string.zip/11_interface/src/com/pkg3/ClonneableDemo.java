package com.pkg3;

import com.pkg1.Address;
import com.pkg1.Employee;
import com.pkg1.Manager;

public class ClonneableDemo {
	
	public static void main(String[] args) throws CloneNotSupportedException {
		cloneExp();
	}
	
	public static void cloneExp() throws CloneNotSupportedException {
		Address add1 = new Address("Pune", 411028);
		Employee emp1 = new Employee(2, "Jack", 1000);
		emp1.setAddress(add1);
		
		
		Employee emp2 =  (Employee)emp1.clone();
		
		emp1.getAddress().setCity("Mumbai");
		
		System.out.println(emp1.equals(emp2));
		System.out.println(emp1 == emp2);
		System.out.println(emp1.getAddress() == emp2.getAddress());
		
		System.out.println(emp1);
		System.out.println(emp2);
		
	}
	
	public static void exp1() {
		Employee emp1 = new Employee(2, "Jack", 1000);
		Employee emp2 = new Employee(2, "Jack", 1000);
		
		System.out.println(emp1 == emp2);
		
		System.out.println(null instanceof Employee);

		System.out.println(emp1.equals(null));
		
		System.out.println(emp1.equals(emp2));
		
		Manager manger1 = new Manager(1, "John", 5000, 10);
		Manager manger2 = new Manager(1, "John", 5000, 10);
		System.out.println(manger1.equals(manger2));
		
		System.out.println(emp1.hashCode());
		System.out.println(emp2.hashCode());
	}

}
