package com.seed.main;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;

public class MapDemo {
	
	public static void exp1() {
		Map<String, Integer> map = new HashMap<String, Integer>();
		Integer b1, b2;
		b1=map.put("Java", 10);
		map.put("Spring", 7);
		map.put("Hibernate", 6);
		map.put("Springboot", 6);
		b2=map.put("Java",11);
		
		System.out.println(map);
		
		System.out.println(b1);
		System.out.println(b2);
		display1(map);
	}
	
	
	//wap to prrint no of character occurences eg: abcabaa  a=3  b=3 c=1
	//abcd aaa def   a=4, b=1, c-1, d=2
	public static void printCharOccurence(String str) {
		char[] carr= str.toCharArray();
		Map<Character, Integer> map = new TreeMap<Character, Integer>();
		for(char c:carr) {
			Integer count=map.put(c, 1);
			if(count != null) {
				map.put(c, count+1);
			}
		}
		System.out.println(map);
	}
	
	public static void display1(Map<String,Integer> map) {
		Set<String> keySet = map.keySet();
		for(String key:keySet) {
			System.out.println(key+"="+map.get(key));
		}
		System.out.println("---------------------------");
	}
	
	public static void display2(Map<String,Integer> map) {
		Set<Entry<String, Integer>> entrySet = map.entrySet();
		for(Entry<String, Integer> entry:entrySet) {
			System.out.println(entry.getKey()+"="+entry.getValue());
		}
		
	}

	public static void main(String[] args) {
		exp1();
	}

}

interface A {
	public void one();
}

interface B extends A {
	public void two();
}

interface C extends B {
	public void three();
}

class X implements C {

	@Override
	public void two() {
		// TODO Auto-generated method stub

	}

	@Override
	public void one() {
		// TODO Auto-generated method stub

	}

	@Override
	public void three() {
		// TODO Auto-generated method stub

	}

}
