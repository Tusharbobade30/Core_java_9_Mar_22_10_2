package com.seed.main;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.NavigableSet;
import java.util.Set;
import java.util.TreeSet;

import com.seed.Employee;

public class SetDemo {

	// HashSet is unordered and unsorted
	public static void exp1() {
		List<Integer> ilist = new ArrayList<Integer>();
		ilist.add(1);
		ilist.add(12);
		ilist.add(3);
		ilist.add(1);
		ilist.add(1);

		Set<Integer> iset = new HashSet<>();
		boolean b1, b2;
		iset.add(1);
		b1 = iset.add(12);
		iset.add(3);
		iset.add(1);
		b2 = iset.add(1);
		iset.add(2);
		iset.add(120);

		System.out.println(b1);
		System.out.println(b2);

		System.out.println(ilist.size());
		System.out.println(iset.size());

		System.out.println(ilist);
		System.out.println(iset);

	}

	// LinkedHashSet is ordered
	public static void exp2() {
		Set<Integer> iset = new LinkedHashSet<>();

		iset.add(1);
		iset.add(12);
		iset.add(3);
		iset.add(2);
		iset.add(120);

		System.out.println(iset);
	}

	// TreeSet is Sorted
	public static void exp3() {
		Set<Integer> iset = new TreeSet<>();

		iset.add(1);
		iset.add(12);
		iset.add(3);
		iset.add(2);
		iset.add(120);

		System.out.println(iset);
	}

	// sort HashSet in default order
	public static void exp4() {
		Set<Integer> iset = new HashSet<>();

		iset.add(1);
		iset.add(12);
		iset.add(3);
		iset.add(2);
		iset.add(120);

		iset = new TreeSet<>(iset);
		System.out.println(iset);
	}

	// sort HashSet in reverse order
	public static void exp5() {
		Set<Integer> iset = new HashSet<>();

		iset.add(1);
		iset.add(12);
		iset.add(3);
		iset.add(2);
		iset.add(120);

		Set<Integer> iset1 = new TreeSet<>(Collections.reverseOrder());
		iset1.addAll(iset);
	}

	public static void exp6() {
		Set<Integer> iset = new HashSet<>();

		iset.add(1);
		iset.add(12);
		iset.add(3);
		iset.add(2);
		iset.add(120);

		System.out.println(iset.contains(3));

	}

	private static Set<Employee> getEmpSet() {
		Set<Employee> set = new HashSet<Employee>();

		Employee emp1 = new Employee(1, "John", 5000);
		Employee emp2 = new Employee(7, "Abel", 3000);
		Employee emp3 = new Employee(1, "John", 5000);
		Employee emp4 = new Employee(4, "Grant", 50000);
		Employee emp5 = new Employee(3, "Zlotkey", 15000);
		Employee emp6 = new Employee(2, "Mary", 1000);

		set.add(emp1);
		set.add(emp2);
		boolean b = set.add(emp3);
		set.add(emp4);
		set.add(emp5);
		set.add(emp6);

		System.out.println(b);
		System.out.println(emp1.equals(emp3));
		System.out.println("emp1 hashcode: " + emp1.hashCode());
		System.out.println("emp3 hashcode: " + emp3.hashCode());

		return set;
	}

	public static void display(Set<?> set) {
		Iterator<?> itr = set.iterator();
		while (itr.hasNext()) {
			System.out.println(itr.next());
		}
		System.out.println("------------------------------------------");
	}

	public static void exp7() {
		Employee emp1 = new Employee(1, "John", 5000);
		Employee emp2 = new Employee(7, "Abel", 3000);
		Employee emp3 = new Employee(1, "John", 5000);
		Employee emp4 = new Employee(4, "Grant", 50000);
		Employee emp5 = new Employee(3, "Zlotkey", 15000);
		Employee emp6 = new Employee(2, "Mary", 1000);


		Set<Employee> set = new TreeSet<Employee>(new Comparator<Employee>() {

			@Override
			public int compare(Employee o1, Employee o2) {
				return o2.getName().compareTo(o1.getName());
			}
		});
		set.add(emp1);
		set.add(emp2);
		set.add(emp3);
		set.add(emp4);
		set.add(emp5);
		set.add(emp6);

		display(set);
		
		class SalComparator implements Comparator<Employee> {
			@Override
			public int compare(Employee o1, Employee o2) {
				return Double.valueOf(o1.getSalary()).compareTo(o2.getSalary());
			}
		}

		SalComparator salComparator = new SalComparator();

		NavigableSet<Employee> set1 = new TreeSet<Employee>(salComparator);
		set1.add(emp1);
		set1.add(emp2);
		set1.add(emp3);
		set1.add(emp4);
		set1.add(emp5);
		set1.add(emp6);
		
		display(set1);
		
		NavigableSet<Employee> descendingSet = set1.descendingSet();
		display(descendingSet);

		
		
	}

	public static void main(String[] args) {
		exp7();
	}

}
