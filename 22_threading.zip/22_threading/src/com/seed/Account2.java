package com.seed;

import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class Account2 extends Account {

	private Integer accountId;
	private AtomicInteger balance;

	public Account2() {
		// TODO Auto-generated constructor stub
	}

	public Account2(Integer accountId, Integer balance) {
		super();
		this.accountId = accountId;
		this.balance = new AtomicInteger(balance);
	}

	public Integer getAccountId() {
		return accountId;
	}

	public void setAccountId(Integer accountId) {
		this.accountId = accountId;
	}
	
	@Override
	public Integer getBalance() {
		return balance.get();
	}
	
	@Override
	public void setBalance(Integer balance) {
		this.balance.set(balance);
	}


	@Override
	public String toString() {
		return "Account [accountId=" + accountId + ", balance=" + balance + "]";
	}

	public void deposit(int amount) {
		
		System.out.println("money deposit is in progress....");
		balance.addAndGet(amount);
		System.out.println("amount deposited successfully");
		System.out.println("Current balance: " + balance);
		System.out.println();
		

	}

	public void withdraw(int amount) {
		
		System.out.println("money withdaw is in progress....");

		balance.addAndGet(-1*amount);
		System.out.println("amount withdrawn successfully");
		System.out.println("Current balance: " + balance);
		System.out.println();
		

	}

}
