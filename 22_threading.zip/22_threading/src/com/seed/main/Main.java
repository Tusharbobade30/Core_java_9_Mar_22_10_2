package com.seed.main;

import com.seed.MyThread;

public class Main {
	
	public static void main(String[] args) {
		
	}
	
	public static void priorityExp() {
		System.out.println("main start");
		Thread ob= new MyThread();
		
		Thread t1=new Thread(ob,"one");
		Thread t2=new Thread(ob,"two");
		
		t2.setPriority(Thread.MAX_PRIORITY);
		t1.setPriority(4);
		

		t1.start();
		t2.start();
		
		Thread.yield();
		
		System.out.println(1/0);
		
		try {
			Thread.sleep(14000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("main end");
		
	}
	
	public static void daemonExp() {
		System.out.println("main start");
		Thread ob= new MyThread();
		
		Thread t1=new Thread(ob,"one");
		Thread t2=new Thread(ob,"two");
		
		t2.setDaemon(true);
		

		t1.start();
		t2.start();
		
		try {
			Thread.sleep(14000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("main end");
	}
	
	public static void joinExp() {
		System.out.println("main start");
		Thread ob= new MyThread();
		
		Thread t1=new Thread(ob,"one");
		Thread t2=new Thread(ob,"two");
		
		t1.start();
		t2.start();
		try {
			t1.join();
			t2.join();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
		System.out.println("main end");
	}
	
	

}
