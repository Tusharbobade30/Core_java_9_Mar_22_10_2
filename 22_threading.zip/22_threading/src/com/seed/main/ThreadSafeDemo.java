package com.seed.main;

import com.seed.Account;
import com.seed.Account1;
import com.seed.Account2;
import com.seed.Bank;

public class ThreadSafeDemo {
	
	public static void exp1() throws InterruptedException {
		Account account = new Account(1,15000);
		final Bank bank =new Bank(account);
		
		Thread t1=new Thread() {
			@Override
			public void run() {
				bank.withdraw();
			}
		};
		
		Thread t2=new Thread() {
			@Override
			public void run() {
				bank.deposit();
			}
		};
		
		t1.start();
		t2.start();
		
		
		
		//System.out.println(account.getBalance());
	}
	
	
	public static void exp2() throws InterruptedException {
		Account2 account = new Account2(1,15000);
		final Bank bank =new Bank(account);
		
		Thread t1=new Thread() {
			@Override
			public void run() {
				bank.withdraw();
			}
		};
		
		Thread t2=new Thread() {
			@Override
			public void run() {
				bank.deposit();
			}
		};
		
		t1.start();
		t2.start();
		
		
		
		//System.out.println(account.getBalance());
	}
	
	public static void main(String[] args) {
		try {
			exp2();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
