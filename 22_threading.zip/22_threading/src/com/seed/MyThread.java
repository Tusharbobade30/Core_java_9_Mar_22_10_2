package com.seed;

public class MyThread extends Thread{
	int x=1;
	
	@Override
	public void run() {
		String name=Thread.currentThread().getName();
		System.out.println("Thread "+name+" start");
		for(int i=0;i<10;i++) {
			System.out.println(name+"  "+x);
			x++;
			try {
				if(name.equals("one")) {
					Thread.sleep(500);
				}else {
					Thread.sleep(2000);
				}
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		System.out.println("Thread "+name+" end");
	}

}
