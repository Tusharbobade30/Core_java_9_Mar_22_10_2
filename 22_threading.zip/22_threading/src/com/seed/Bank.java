package com.seed;

public class Bank extends Thread {

	private Account account;

	public Bank(Account account) {
		this.account = account;
	}
	
	public void withdraw() {
		for(int i=1;i<=10;i++) {
			account.withdraw(1000);
			pause(1000);
		}
	}
	
	public void deposit() {
		for(int i=1;i<=10;i++) {
			account.deposit(500);
			pause(1000);
		}
	}
	
	public void pause(int num) {
		try {
			Thread.sleep(num);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
