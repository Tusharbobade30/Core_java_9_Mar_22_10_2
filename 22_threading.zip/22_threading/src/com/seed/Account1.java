package com.seed;

public class Account1 extends Account {

	private Integer accountId;
	private Integer balance;

	public Account1() {
		// TODO Auto-generated constructor stub
	}

	public Account1(Integer accountId, Integer balance) {
		super();
		this.accountId = accountId;
		this.balance = balance;
	}

	public Integer getAccountId() {
		return accountId;
	}

	public void setAccountId(Integer accountId) {
		this.accountId = accountId;
	}

	public Integer getBalance() {
		return balance;
	}

	public void setBalance(Integer balance) {
		this.balance = balance;
	}

	@Override
	public String toString() {
		return "Account [accountId=" + accountId + ", balance=" + balance + "]";
	}

	public  void deposit(int amount) {
		System.out.println("money deposit is in progress....");
		synchronized (this) {
			this.balance = this.balance + amount;
			System.out.println("amount deposited successfully");
			System.out.println("Current balance: " + balance);
		}
		
	}

	public  void withdraw(int amount) {
		System.out.println("money withdaw is in progress....");
		synchronized (this) {
			this.balance = this.balance - amount;
			System.out.println("amount withdrawn successfully");
			System.out.println("Current balance: " + balance);
		}
		
	}

}
