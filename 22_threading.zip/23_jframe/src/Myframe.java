import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class Myframe extends JFrame {
	
	JLabel lbId;
	JLabel lbName;
	JTextField txId;
	JTextField  txName;
	JButton button;
	Container container;
	
	public Myframe() {
		
		this.container = getContentPane();
		//this.setLayout(new FlowLayout());
		this.setLayout(null);
		
		lbId = new JLabel("Id");
		lbName = new JLabel("Name");
		
		lbId.setBounds(10, 10, 50, 20);
		lbName.setBounds(10, 35, 50, 20);
		
		txId = new JTextField(10);
		txName = new JTextField(20);
		
		txId.setBounds(70, 10, 120, 20);
		txName.setBounds(70, 30, 120, 20);
		
		button = new JButton("Add");
		
		button.setBounds(50,60 , 70, 20);
		
		container.add(lbId);
		container.add(txId);
		
		container.add(lbName);
		container.add(txName);
		
		container.add(button);
		
		button.addActionListener(new MyActionListener());
		
		container.addMouseListener(new MyMouseListener());
		
		this.setName("My First Frame");
		this.setSize(400, 400);
		this.setVisible(true);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
	}
	
	
	class MyActionListener implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent e) {
			System.out.println("button clicked");
		}
		
	}
	
	class MyMouseListener implements MouseListener {

		@Override
		public void mouseClicked(MouseEvent e) {
			System.out.println("mouse cliked");
			
		}

		@Override
		public void mousePressed(MouseEvent e) {
			System.out.println("mousePressed");
			
		}

		@Override
		public void mouseReleased(MouseEvent e) {
			System.out.println("mouse released");
			
		}

		@Override
		public void mouseEntered(MouseEvent e) {
			System.out.println("mouse entered");
			
		}

		@Override
		public void mouseExited(MouseEvent e) {
			System.out.println("mouse exit");
			
		}
		
	}

}

