import javax.swing.JFrame;

public class Demo {
	
	public static void main(String[] args) {
		JFrame frame =new Myframe();
	}

}
