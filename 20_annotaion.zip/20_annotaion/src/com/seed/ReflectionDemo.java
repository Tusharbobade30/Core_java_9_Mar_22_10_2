package com.seed;

import java.lang.annotation.Annotation;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;



public class ReflectionDemo {
	
	public static void main(String[] args) {
		exp1();
		Employee emp=new Employee();
		emp.calculateSalary(0, 0, 0);
		
		
		 try {
			Class c =  Class.forName("com.seed.Employee");
			Employee emp1 = (Employee) c.newInstance();
			System.out.println(emp1==emp);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public static void exp1() {
		Employee emp = new Employee();
		 Class<? extends Employee> clazz = emp.getClass();
		 
		 try {
			 Class c =  Class.forName("com.seed.Employee");
			 Field[] fields = c.getDeclaredFields();
			 for(Field f:fields) {
				 int modifiers = f.getModifiers();
				 System.out.print(Modifier.toString(modifiers)+" ");
				 System.out.print(f.getType()+" ");
				 System.out.println(f.getName());
			 }
			 
			 Method[] methods = c.getDeclaredMethods();
			 
			 for(Method f:methods) {
				 int modifiers = f.getModifiers();
				 System.out.print(Modifier.toString(modifiers)+" ");
				 System.out.print(f.getReturnType()+" ");
				 System.out.println(f.getName());
				 
				 Annotation[] annos = f.getDeclaredAnnotations();
				 for(Annotation a:annos) {
					 System.out.println(a);
				 }
				 
				 System.out.println("--------------------------------------");
		
			 }
			 
			 
			 
			 
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

}
