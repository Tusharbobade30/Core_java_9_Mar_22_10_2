package com.seed;

import java.util.ArrayList;
import java.util.List;

import com.seed.annotation.MyAnno;

/**
 * @author comp
 *
 */
//@MyAnno(message = "Employee class")
@SuppressWarnings({ "rawtypes", "unused" })
public class Employee {
	
	//@MyAnno(message="Property to identify the employee uniquely")
	private int id;
	private String name;
	private double salary;
	

	public Employee() {
	}
	
	@MyAnno(message = "parameterized constructor")
	public Employee(int id, String name, double salary) {
		super();
		this.id = id;
		this.name = name;
		this.salary = salary;
	}

	@Override
	@MyAnno(message = "overiding the method of object class")
	public String toString() {
		return super.toString();
	}
	
	
	/**
	 * @param hra hra will be calculated based on 40% fixed or 10% of total income
	 * @param salary fixed salary
	 * @param bonus yearly bonus
	 */

	@MyAnno(message = "calucalate the net salary")
	@Deprecated
	public void calculateSalary(double hra,double salary,double bonus) {
		
		
		List list= new ArrayList();
		
		long a=10;
	}
	
	public void computeSalary() {
		
	}

}
