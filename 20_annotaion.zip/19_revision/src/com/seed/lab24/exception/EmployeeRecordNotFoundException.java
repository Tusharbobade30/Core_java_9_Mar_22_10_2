package com.seed.lab24.exception;

public class EmployeeRecordNotFoundException extends Exception{
	
	

}
