package com.seed.lab24.util;

import java.util.List;

import com.seed.lab24.Employee;
import com.seed.lab24.exception.EmployeeRecordNotFoundException;

public class SearchUtil {
	
	public static Employee searchEmployee(List<Employee> list, int empNo) throws EmployeeRecordNotFoundException {
		
		
		 throw new EmployeeRecordNotFoundException();
	}

}
