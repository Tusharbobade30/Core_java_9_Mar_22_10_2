package com.seed.lab24.util;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.seed.lab24.Employee;

public class UtilityReport {
	
	public static Map<String, Double> getReport(List<Employee> list){
		Map<String, Double> report = new HashMap<String, Double>();
		for(Employee emp : list ) {
			report.put(emp.getName(), emp.getSalary());
		}
		return report;
	}
	
	public static void showReport(Map<String,Double> report) {
		//name->salary
	}
	
	public static void showReport(List<Employee> employees) {
		 Map<String, Double> report = getReport(employees);
		 showReport(report);
	}

}
