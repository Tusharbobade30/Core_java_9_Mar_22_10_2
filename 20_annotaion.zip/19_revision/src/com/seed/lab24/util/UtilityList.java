package com.seed.lab24.util;

import java.util.List;

import com.seed.lab24.Employee;

public class UtilityList {
	
	public static void printList(List<Employee> list) {
		for(Employee emp : list ) {
			System.out.println("Id  : "+emp.getId());
			System.out.println("Name:"+emp.getName());
			System.out.println("Salary:"+emp.getSalary());
			System.out.println("Skills: ");
			System.out.println("--------");
			for( String skill :emp.getSkillSet()) {
				System.out.println("\n"+skill);
			}
			System.out.println();
			System.out.println("____________________________________");
		}
	}

}
