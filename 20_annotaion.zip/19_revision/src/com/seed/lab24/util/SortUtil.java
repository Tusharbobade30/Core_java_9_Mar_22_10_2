package com.seed.lab24.util;

import java.util.Collections;
import java.util.List;

import com.seed.lab24.Employee;

public class SortUtil {

	public static void sort(List<Employee> list) {
		Collections.sort(list);
	}

	public static void sortBySalary(List<Employee> list) {

	}

	public static void sortByName(List<Employee> list) {

	}

}
