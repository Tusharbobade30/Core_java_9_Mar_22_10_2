package com.seed.lab24.main;

public class Main {
	
	public static void assertDemo(int x) {
		
		int age=x;
		age = age+10;
		
		System.out.println("before assert1: "+age);
		assert(age<100);
		
		System.out.println("after assert1: "+age);
		
		age =age +20;
		assert age<100 : "cannot be greate than 100";
		
		
		System.out.println("after assert2: "+age);
	}
	
	public static int foo() {
		return 10;
	}
	
	public static void ifELseExp() {
		/*
		 * conditional error:  
		 * >
		 * >=
		 * <
		 * <=
		 * ==
		 * !=
		 * instanceof
		 * 
		 Logical operator
		 1. and  &&
		      if(condition1 && condition2){ 
		      
		      }
		 2. or    ||
		 
		   if(condition1 || condition2){ 
		      
		   }
		   
		 3. not  !
		    if(!condition){ 
		      
		     }
		 
		 
		 
		 
		 1.
			 if(condtion){
			 
			 }
		 
		 
		 2. 
		    if(condition){
		    
		    }else{
		    
		    }
		    
		    
		 3. if(condition1){
		 
		    }else if(condition2){
		    
		    }else if(condition3){
		    
		    }else{
		      
		    }
		 * 
		 */
		
		//ternary
		int a=10;
		String str = a%2==0?"even"  :"odd";
		
		if(a%2==0) {
			str="even";
		}else {
			str ="odd";
		}
	}
	
	public static void loopExp() {
		//type of loops
		/*
		  1. Pre testing
		  		a. while
		  		b. for
		  		   i) simple loop
		  		      for(initialization ; condition ; increment/decrement){
		  		      
		  		      }
		  		      for(int i=0;i<10;i++){
		  		      
		  		      }
		  		   
		  		   ii) enhance for loop or for each loop
		  		   
		  2. post testing
		        a. do while
		        do{
		        
		        }while(condition);
		 */
		
	}
	
	public static int sumOfDigit(int num) {
		int temp =num; //12345
		int sum =0;
	
		while(temp!=0){
			int rem = temp%10;
			sum = sum+ rem;
			temp = temp/10;
		}
		
		return sum;
	}
	
	public static boolean isPrime(int num) {
		if(num<=1) {
			return false;
		}
		for(int i=2;i<=Math.sqrt(num);i++) {
			if(num%i == 0) {
				return false;
			}
		}
		return true;
	}
	
	public static void main(String[] args) {
		assertDemo(80);
	}

}

