
public class Test {
	public static void main(String[] args) {
		
		System.out.println("start");
		int age =Integer.parseInt(args[0]);
		
		System.out.println("Age= "+age);
		assert age<100:"Age cannot be greater than 100";
		
		System.out.println("end");

	}
}



//file handling  serialization
//multithreading : complex
//jdbc  


//reflection and annotation
//desktop
//socket programing