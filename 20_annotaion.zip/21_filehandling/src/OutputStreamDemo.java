import java.io.DataOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class OutputStreamDemo {
	
	public static void write1() {
		String filename="a.txt";
		File f= new File(filename);
		try(FileOutputStream fos= new FileOutputStream(f)) {
			fos.write(new byte[] {65,66,67,68});
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	public static void write2() {
		String filename="a.txt";
		File f= new File(filename);
		try(FileOutputStream fos= new FileOutputStream(f);
			DataOutputStream dos= new DataOutputStream(fos);
				) {
			dos.writeBytes("This is the demo");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static void write3() {
		String filename="b.txt";
		File f= new File(filename);
		try(FileWriter fw= new FileWriter(f);
			
				) {
			fw.write("this is the example of Writer class");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	public static void write4() {
		String filename="c.txt";
		File f= new File(filename);
		try(FileWriter fw= new FileWriter(f,true);
				PrintWriter pw= new PrintWriter(fw);
			
				) {
			pw.println("this is the example of Writer class");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		write4();
	}

}
