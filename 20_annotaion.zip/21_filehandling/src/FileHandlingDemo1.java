import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.util.Scanner;

public class FileHandlingDemo1 {
	
	public static void fileDemo() throws IOException {
		File f= new File("a");
		System.out.println(f.getAbsolutePath());
		System.out.println(f.exists());
		System.out.println(f.createNewFile());
		System.out.println(f.canWrite());
		
		
	}
	
	public static void read1(String filename) {
		FileInputStream fis=null;
		
		try {
			fis = new FileInputStream(filename);
			
				int i=0;
				while((i=fis.read())!=-1) {
					System.out.print((char)i);
				};
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}catch(IOException e) {
			e.printStackTrace();
		}finally {
			if(fis != null) {
				try {
					fis.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		
	}
	
	public static void read2(String filename) {
		try(FileInputStream fis= new FileInputStream(filename)){
			int i=0;
			while((i=fis.read())!=-1) {
				System.out.print((char)i);
				Thread.sleep(10);
			};
		}catch(IOException|InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	public static void read3(String filename) {
		try(FileInputStream fis=new FileInputStream(filename);
				DataInputStream dis= new DataInputStream(fis);){
			String str=null;
			while((str=dis.readLine())!= null) {
				System.out.println(str);
				Thread.sleep(100);
			}
		}catch(IOException|InterruptedException e) {
			e.printStackTrace();
		}
		
	}
	
	public static void read4(String filename) {
		try(Scanner sc=new Scanner(new FileInputStream(filename))){
			String str=null;
			str=sc.next();
			System.out.println(sc);
		}catch(Exception e) {
			e.printStackTrace();
		}
		
	}
	
	
	public static void read5(String filename) {
		try(FileReader reader=new FileReader(filename)){
			int i=0;
			while((i=reader.read())!=-1) {
				System.out.print((char)i);
				Thread.sleep(10);
			};
		}catch(IOException|InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	public static void read6(String filename) {
		try(FileReader reader=new FileReader(filename);
				BufferedReader br=new BufferedReader(reader);
				){
			String str=null;
			while((str=br.readLine())!= null) {
				System.out.println(str);
				Thread.sleep(100);
			}
			
		}catch(IOException|InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	
	public static void main(String[] args)  throws Exception{
		String filename="D:\\Ram\\classes\\workspace\\seed\\java_9_mar_22\\21_filehandling\\src\\FileHandlingDemo1.java";
		read6(filename);
	}
	
	
	

}
