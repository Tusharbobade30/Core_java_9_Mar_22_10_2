package com.pkg1;

public class SalesPerson extends Employee{

}
