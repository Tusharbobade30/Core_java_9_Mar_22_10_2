package com.pkg1;

public class Employee {
	private int id;
	private String name;
	private double salary;

	public Employee() {
		System.out.println("Default Employee constructor");
	}

	public Employee(int id, String name, double salary) {
		System.out.println("Paramterized Employee constructor");
		this.id = id;
		this.name = name;
		this.salary = salary;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public void display() {
		System.out.println("Id: " + id + "\tName:" + name + "\tSalary: " + salary);
	}

	public double computeNetSalary() {
		return salary;
	}

}
