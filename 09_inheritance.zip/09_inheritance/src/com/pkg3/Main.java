package com.pkg3;

import com.pkg1.Employee;
import com.pkg2.Manager;

public class Main {
	
	public static void main(String[] args) {
		Employee emp= new Employee();
		
		Manager mgr1 = new Manager();
		mgr1.display();
		
		printLine();
		
		Manager mgr2 = new Manager(1,"John",5000,10);
		mgr2.display();
	}
	
	public static void printLine() {
		System.out.println("-------------------------------------------------------");
	}

}
