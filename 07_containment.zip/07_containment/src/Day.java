
public class Day {
	String day;

	public Day(String day) {
		this.day = day;
	}
}
