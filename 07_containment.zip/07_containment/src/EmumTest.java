
public class EmumTest {
	
	public static void main(String[] args) {
		Day mon= new Day("MON");
		Day tue= new Day("TUE");
		Day wed= new Day("WED");
		Day thu= new Day("THU");
		Day fri= new Day("FRI");
		Day sat= new Day("SAT");
		Day sun= new Day("SUN");
		
		Day fun= new Day("FUN");
		
	}

}
