
public class Main {
	
	public static void main(String[] args) {
		Employee emp = new Employee();
		emp.setId(10);
		emp.setName("Jessica");
		emp.setSalary(5000);
		emp.setMailingAddress(new Address("Mumbai",411101));
		emp.setPermanentAddress(new Address("pune",411042));
		System.out.println(emp);
		
		printLine();
		
		Employee emp1 = new Employee(1, "Jack", 1000);
		Address permAddress1 = new Address("Pune", 411041);
		emp1.setPermanentAddress(permAddress1);
		
	
		emp1.setMailingAddress(new Address("Kolkata", 700013));
		
		System.out.println(emp1);
		
		printLine();
		
		Address mailAddress2 = new Address("Pune", 411042);
		Address PermAddress2 = new Address("Kolkata", 700012);
		Employee emp2 = new Employee(2, "John", 4000, mailAddress2, PermAddress2);
		System.out.println(emp2);
		
		Employee emp3 = new Employee(3,"Sam",3000, 
				new Address("Bhopal",12345),
				new Address("Pune",11111));
		System.out.println(emp3);
		
	}
	
	public static void printLine() {
		System.out.println("-----------------------------------------------------------------");
	}

}
