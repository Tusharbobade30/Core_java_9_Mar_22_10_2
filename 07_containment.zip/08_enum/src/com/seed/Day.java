package com.seed;

public enum Day {
	SUN(1,"Sunday"), MON(2,"Monday"), TUE(3,"Tuesday"), 
	WED(4,"Wednesay"), THU(5,"Thursday"), FRI(6,"Friday"), SAT(7,"Saturday");
	
	private int id;
	private String value;
	private Day(int id,String value){
		this.id=id;
		this.value =value;
	}
	
	public int getId() {
		return id;
	}
	
	public String getValue() {
		return value;
	}
	
	
	public static Day getDay(String val) {
		for( Day d: Day.values()) {
			if(d.getValue().equalsIgnoreCase(val)) {
				return d;
			}
		}
		return null;
	}
}
