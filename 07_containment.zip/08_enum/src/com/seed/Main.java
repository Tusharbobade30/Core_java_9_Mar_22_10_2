package com.seed;

public class Main {
	public static void main(String[] args) {
		Day d = Day.MON;
		Day tue = Day.TUE;
		
		for(Day x :Day.values()) {
			System.out.println(x);
			System.out.println(x.ordinal());
			System.out.println(x.name());
			System.out.println(x.getId());
			System.out.println(x.getValue());
			System.out.println("----------------------------------");
		}
		
		Day d1 = Day.getDay("sunday1");
		System.out.println(d1);
	}

}
