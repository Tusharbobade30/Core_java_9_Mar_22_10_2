Array is first class object

