package com.seed;

import java.util.Arrays;
import static java.util.Arrays.sort;

public class ArrayDemo {

	//instance member /object member
	//class member/method
	static int a;
	
	public static void main(String[] args) {
		
		ArrayDemo ob =  new ArrayDemo();
		
		int[] arr = {10000,20,300,40};
		
		//System.out.println(ArrayDemo.getMax(arr));
		
		sort(arr);
		
		ArrayDemo.display1(arr);
		
		MyDate[] darr = new MyDate[3];
		darr[0] = new MyDate(1, 1, 2001);
		darr[1] = new MyDate(2, 2, 2001);
		darr[2] = new MyDate(3, 3, 2001);
		
		darr[1].setDay(5);
		
		for( MyDate d : darr) {
			System.out.println(d);
		}
		
	}
	
	
	public static void display1(int[] arr) {
		//enhanced for loop
		for( int a :arr ) {
			System.out.print(a+" ");
		}
		System.out.println();
	}
	
	public static void display(int[] arr) {
		for(int i=0;i<arr.length;i++) {
			System.out.print(arr[i]+ " ");
		}
		System.out.println();
	}
	
	public static int getMax(int[] arr) {
		int max = arr[0];
		for(int i=1;i<arr.length;i++) {
			if(max<arr[i]) {
				max = arr[i];
			}
		}
		return max;
	}

}
