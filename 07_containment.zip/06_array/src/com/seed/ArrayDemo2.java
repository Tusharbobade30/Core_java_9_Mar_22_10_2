package com.seed;

public class ArrayDemo2 {
	
	public static void main(String[] args) {
		int[][] arr = new int[2][3];
		
		arr[0][2] = 500;
		display2DArray(arr);
		
		//int barr[][] = new int[][3];  //invalid
		int carr[][] = new int[2][];
		//int darr[][] = new int[][];
		
		carr[0]  = new int[3];
		carr[1] =new int[2];
		
		display2DArray(carr);
		
		int[][] darr = {{1,2},{2,4,6,8},{3,6,9}};
		display2DArray(darr);
		
		
	}
	
	public static void display2DArray(int[][] arr) {
		/*for(int i=0;i<arr.length;i++) {
			for(int j=0;j<arr[i].length;j++) {
				System.out.print(arr[i][j]+"  ");
			}
			System.out.println();
		}*/

		for(int[] ar  : arr) {
			for( int a : ar) {
				System.out.print(a+"  ");
			}
			System.out.println();
		}
		System.out.println();
	}

}
