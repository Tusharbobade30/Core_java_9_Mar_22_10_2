
public class Test {
	
	public static void main(String[] args) {
		System.out.println("Hello World");
	}
	
	public static void checkPrime(int num) {
		if(num<=1) {
			System.out.println(num+" is not a prime number");
		}
		
	}
	
	public static void checkEven(int num) {
		
	}
	
	public static void printPattern1() {
		
	}
	
    public static void printPattern2() {
		
	}

}

//pattern 1
/*
   *
  ***
 *****
*******
*/

//pattern 2
/*
    *
   ***
  *****
 *******
  *****
   ***
    *
 
*/
