this: reference to the current object implicitly present in all the instance member and constructor
Use:
1. remove the shawdowing of variable
2. this contructor 
  rule: it must be first line.

  static block
    TODO: can we use more than 1 static block. If yes, then what will the order
    