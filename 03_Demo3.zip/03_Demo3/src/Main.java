
public class Main {

	public static void main(String[] args) {
		
	}

	/*
	 * 
	 */
	public static void problemStatement1() {

	}

	public static void problemStatement2() {

	}

	public static void problemStatement3() {

	}

}
