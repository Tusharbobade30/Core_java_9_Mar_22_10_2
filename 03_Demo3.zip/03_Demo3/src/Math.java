
public class Math {
	public static final double PI= 3.14;
	
	static {
		System.out.println("one");
	}
	
	static {
		System.out.println("two");
	}
	
	static {
		System.out.println("three");
	}
	

}
