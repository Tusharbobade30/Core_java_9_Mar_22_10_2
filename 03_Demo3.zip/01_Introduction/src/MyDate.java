
public class MyDate {
	
	int dd;
	int mm;
	int yy;
	
	
	public void display() {
		System.out.println(dd+"-"+ mm +"-"+yy);
	}
	
	
	

}
