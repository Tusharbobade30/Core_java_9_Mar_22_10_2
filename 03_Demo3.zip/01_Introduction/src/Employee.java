
public class Employee {
	
	int id;
	String name;
	double salary;
	
	void display() {
		System.out.println("Id: "+id);
		System.out.println("Name: "+name);
		System.out.println("Salary: "+salary);
	}

}
