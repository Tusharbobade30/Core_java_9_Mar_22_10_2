package com.seed.main;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;
import java.util.stream.Collectors;

import static java.util.Collections.*;

import com.seed.Employee;

public class ListDemo1 {
	
	public static void main(String[] args) {
		java8Example();
	}
	
	public static void java8Example() {
		List<Employee> list = getEmpList();
		
		List<Employee> list1= list.stream().sorted((e1,e2)->{ return e1.getName().compareTo(e2.getName());}).collect(Collectors.toList());
		
		List<Employee> evenList = list.stream().filter(e->e.getId()%2 !=0).collect(Collectors.toList());
		displayList(list1);
	}
	
	
	//reverse order
	public static void sortExample2() {
		List<Employee> empList = getEmpList();
		displayList(empList);
		Collections.sort(empList, Collections.reverseOrder());
		System.out.println("After default sorting");
		displayList(empList);
		
		Collections.sort(empList, Collections.reverseOrder(new SalaryComp()));
		System.out.println("\nAfter sorting by salary");
		displayList(empList);
		
		Collections.sort(empList, Collections.reverseOrder(new Comparator<Employee>() {

			@Override
			public int compare(Employee o1, Employee o2) {
				return o1.getName().compareTo(o2.getName());
			}
		}));
		System.out.println("\nAfter sorting by name");
		displayList(empList);
		
	}
	
	
	public static void sortExample1() {
		List<Employee> empList = getEmpList();
		displayList(empList);
		Collections.sort(empList);
		System.out.println("After default sorting");
		displayList(empList);
		
		Collections.sort(empList, new SalaryComp());
		System.out.println("\nAfter sorting by salary");
		displayList(empList);
		
		Collections.sort(empList, new Comparator<Employee>() {

			@Override
			public int compare(Employee o1, Employee o2) {
				return o1.getName().compareTo(o2.getName());
			}
		});
		System.out.println("\nAfter sorting by name");
		displayList(empList);
		
	}
	
	/*
	 * remove the employee whose id is even
	 * if you delete by foreach method you will get ConcurrentModificationExpection
	 */
	public static void iterationExp1() {
		List<Employee> empList = getEmpList();
		displayList(empList);
	
		for(Employee e: empList) {
			if(e.getId()%2 == 0) {
				empList.remove(e);
			}
		}
	}
	
	/*
	 * remove the employee whose id is even
	 * if you delete by foreach method you will get ConcurrentModificationExpection
	 */
	public static void iterationExp2() {
		List<Employee> empList = getEmpList();
		displayList(empList);
	
		Iterator<Employee> itr = empList.iterator();
		while(itr.hasNext()) {
			Employee e = itr.next();
			if(e.getId()%2 == 0) {
				itr.remove();
				//empList.remove(e);
			}
		}
		
		displayList(empList);
	}
	
	
	/*
	 * add the element while iteration
	 * 
	 */
	public static void iterationExp3() {
		List<Employee> empList = getEmpList();
		displayList(empList);
	
		ListIterator<Employee> itr = empList.listIterator();
		while(itr.hasNext()) {
			Employee e = itr.next();
			if(e.getId()%2 == 0) {
				itr.add(new Employee(e.getId()+100,e.getName(),e.getSalary()));
			}
		}
		
		displayList(empList);
	}
	
	public static void removeExp1() {
		List<Integer> ilist = new ArrayList<Integer>(); 
		ilist.add(1);
		ilist.add(12);
		ilist.add(3);
		ilist.add(11);
		ilist.add(2);
		ilist.add(31);
		
		
		System.out.println(ilist);
		
		ilist.remove(Integer.valueOf(3));
		
		System.out.println(ilist);
		
	}
	
	public static void removeExp2() {
		List<Employee> empList = getEmpList();
		displayList(empList);
		
		Employee emp3 = new Employee(6, "Kochhar", 2000);
		
		empList.remove(emp3);
		
		System.out.println(empList.size());
		displayList(empList);
		
		
		
	}
	
	public static void displayList(List<?> list) {
		for(Object o:list) {
			System.out.println(o);
		}
		line();
		
	}
	
	private static List<Employee> getEmpList(){
		List<Employee> list = new ArrayList<Employee>();
		
		Employee emp1 = new Employee(1, "John", 5000);
		Employee emp2 = new Employee(7, "Abel", 3000);
		Employee emp3 = new Employee(6, "Kochhar", 2000);
		Employee emp4 = new Employee(4, "Grant", 50000);
		Employee emp5 = new Employee(3, "Zlotkey", 15000);
		Employee emp6 = new Employee(2, "Mary", 1000);
		
		list.add(emp1);
		list.add(emp2);
		list.add(emp3);
		list.add(emp4);
		list.add(emp5);
		list.add(emp6);
		
		return list;
	}
	
	public static void line() {
		System.out.println("-----------------------------------------");
	}
	
	
	public static class SalaryComp implements Comparator<Employee>{

		@Override
		public int compare(Employee o1, Employee o2) {
			if(o1.getSalary() > o2.getSalary()) {
				return 1;
			}
			if(o1.getSalary()<o2.getSalary()) {
				return -1;
			}
			return 0;
		}
		
	}
	
	

}
