package com.seed.exception;

public class NotSufficientBalanceException extends Exception {
	
	public NotSufficientBalanceException() {
		super("Not sufficient balance");
	}
	
	public NotSufficientBalanceException(String msg) {
		super(msg);
	}


}
