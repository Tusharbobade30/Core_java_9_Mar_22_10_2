package com.seed;

import com.seed.exception.NotSufficientBalanceException;

public class Account {
	
	private Integer accoutId;
	private double balance;
	
	
	public Account(Integer accoutId, double balance) {
		super();
		this.accoutId = accoutId;
		this.balance = balance;
	}
	
	public void deposit(double amount) {
		balance = balance +amount;
	}
	
	public void withdraw(double amount) throws NotSufficientBalanceException {
		if(amount>=balance) {
			throw new NotSufficientBalanceException("Insufficient balance. Current balance is "+balance);
		}
		balance = balance - amount;
	}
	
}
