package com.seed;

public class Dummy implements AutoCloseable{

	@Override
	public void close() throws Exception {
		System.out.println("dummy close method called");
		
	}

}
