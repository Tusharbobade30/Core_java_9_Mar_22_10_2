package com.seed;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import com.seed.exception.NotSufficientBalanceException;

public class ExceptionDemo {

	public static void main(String[] args) {

		// exp2();
		// fileHandlingExp4();

		exp6();

		try {
			userDefineExceptionExp8();
		} catch (NotSufficientBalanceException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public static void exp1(String[] args) {
		try {
			int num1 = Integer.parseInt(args[0]);
			int num2 = Integer.parseInt(args[1]);
			int res = num2 / num1;
			System.out.println(res);
		} catch (ArrayIndexOutOfBoundsException e) {
			System.out.println("Please pass two arguements");
			e.printStackTrace();
		} catch (NumberFormatException e) {
			System.out.println("Please enter the Integer number only");
			e.printStackTrace();
		} catch (ArithmeticException e) {
			System.out.println("Please enter 1st argument as non zero number");
			e.printStackTrace();
		}
	}

	/*
	 * java 7 feature Multicatch
	 */
	public static void exp2(String[] args) {
		try {
			int num1 = Integer.parseInt(args[0]);
			int num2 = Integer.parseInt(args[1]);
			int res = num2 / num1;
			System.out.println(res);
		} catch (NumberFormatException | ArithmeticException | ArrayIndexOutOfBoundsException e) {
			System.out.println("Please enter the Integer number only and first agrument as non zero");
			e.printStackTrace();
		}
	}

	public static void exp2() {

		Employee emp = new Employee(1, "Jack", 1000);
		try {
			int x = 10 / 0;
		} catch (ArithmeticException e1) {
			e1.printStackTrace();
		}

		try {
			Employee emp1 = emp.clone();
			System.out.println(emp);
			System.out.println(emp1);
		} catch (CloneNotSupportedException e) {
			e.printStackTrace();
		}
	}

	public static void fileHandlingExp3() {
		String filename = "E:\\test\\a.txt";
		filename = "D:\\Ram\\classes\\workspace\\seed\\java_9_mar_22\\15_exception\\src\\com\\seed\\Employee.java";
		FileInputStream fis = null;
		try {
			fis = new FileInputStream(filename);
			int x;
			while ((x = fis.read()) != -1) {
				System.out.print((char) x);
			}
			fis.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
			try {
				fis.close();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		} catch (ArithmeticException e) {
			try {
				fis.close();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}

	}

	public static void fileHandlingExp4() {
		String filename = "E:\\test\\a.txt";
		filename = "D:\\Ram\\classes\\workspace\\seed\\java_9_mar_22\\15_exception\\src\\com\\seed\\Employee.java1";
		FileInputStream fis = null;
		try {
			fis = new FileInputStream(filename);
			int x;
			while ((x = fis.read()) != -1) {
				System.out.print((char) x);
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ArithmeticException e) {

		} finally {
			System.out.println("finally called");
			try {
				fis.close();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}

		}

	}

	/*
	 * Try with resources
	 */
	public static void fileHandlingExp5() {
		String filename = "E:\\test\\a.txt";
		try (FileInputStream fis = new FileInputStream(filename)) {
			int x;
			while ((x = fis.read()) != -1) {
				System.out.print((char) x);
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static void exp6() {
		try (Dummy d = new Dummy()) {
			System.out.println("try block");
		} catch (Exception e) {
			System.out.println("catch block");
		}

		// or

		Dummy d1 = null;
		try {
			d1 = new Dummy();
			//
			//
		} catch (Exception e) {

		} finally {
			if (d1 != null) {
				try {
					d1.close();
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}

	public static void userDefineExceptionExp8() throws NotSufficientBalanceException {
		Account account = new Account(1, 10000);

		account.withdraw(5000);
		account.withdraw(8000);

	}

}
