import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DmlDemo {

	public static void insertExp1() {
		String sql = "insert into emp(id,name,salary) values (2,'Satyajit',5000)";
		Connection connection = ConnectionUtil.getConnection();

		try (Statement st = connection.createStatement()) {
			int x = st.executeUpdate(sql);
			System.out.println(x + " row inserted");
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

	public static void insertExp1(int id, String name, double salary) {
		String sql = "insert into emp(id,name,salary) values (?,?,?)";
		Connection connection = ConnectionUtil.getConnection();

		try (PreparedStatement ps = connection.prepareStatement(sql)) {
			ps.setInt(1, id);
			ps.setString(2, name);
			ps.setDouble(3, salary);
			int x = ps.executeUpdate();
			System.out.println(x + " row inserted");
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

	public static void fetchEmp() {
		String sql = "select id,name,salary from emp";
		Connection connection = ConnectionUtil.getConnection();

		try (Statement st = connection.createStatement()) {
			ResultSet rs = st.executeQuery(sql);
			while(rs.next()) {
				System.out.println(rs.getInt(1)+"   "+rs.getString(2) +"   "+rs.getDouble(3));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public static void dbDetail() {
		Connection connection = ConnectionUtil.getConnection();
		try {
			DatabaseMetaData metaData = connection.getMetaData();
			System.out.println(metaData.getDatabaseProductVersion());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		// insertExp1();
		//insertExp1(3, "John", 1000);
		//insertExp1(4, "jessica", 1000);
		//insertExp1(5, "kim", 1000);
		
		dbDetail();

	}

}
