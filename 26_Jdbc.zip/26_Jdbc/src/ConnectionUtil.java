import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionUtil {
	
	private static Connection connection;
	
	static {
		
		String url="jdbc:oracle:thin:@localhost:1521/ORCLPDB";
		String driverName="oracle.jdbc.driver.OracleDriver";
		String username="hr";
		String password = "hr";
		
		
		
		//load the driver
		try {
			Class.forName(driverName);
			 connection = DriverManager.getConnection(url, username, password);
			System.out.println(connection);
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public static Connection getConnection() {
		return connection;
	}

}
