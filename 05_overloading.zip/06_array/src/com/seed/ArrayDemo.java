package com.seed;

public class ArrayDemo {
	
	public static void main(String[] args) {
		int a=10;
	
		int[] arr = new int[4];
		int barr[] = new int[3];
		int carr[] = {1,2,33,44,5,8,9};
		int [] darr = new int[] {2,3,4};
		
		arr =new int[]{33,44,55};
		
		arr[1] =5555;
		
		
		displayArray(arr);
		displayArray(barr);
		displayArray(carr);
		displayArray(darr);
		
		System.out.println(getMax(carr));
	}
	
	public static void displayArray(int[] arr) {
		for(int i=0;i<arr.length;i++) {
			System.out.print(arr[i]+ " ");
		}
		System.out.println();
	}
	
	public static int getMax(int[] arr) {
		//logic to return max in the array
		return 0;
	}

}
