<hr>Method overloading</hr>
same name but different signature.
1. number of parameter
2. Type of parameter
3. sequence of parameter

Note: signature doen't depend upon return type

int
long
float
double


<hr>
Rules of Varargs<br>
<p>
1. one method have only one varargs argument
2. varargs must me the last arguments

</p>