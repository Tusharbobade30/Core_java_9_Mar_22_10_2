
public class Main {
	
	public static void main(String[] args) {
		Overloading ob = new Overloading();
		//ob.add();
		ob.add(1,2);
		ob.add(1,2,3,4,5,6,7);
		ob.add(1,2,3,4,5,6,7,9,9999,999);
	}

}
