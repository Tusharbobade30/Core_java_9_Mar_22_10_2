
public class Overloading {
	
	//public void add(int a, int b) {}
	//public void add(int a, int b, int c) {}
	
	public void add(int a,int b, int...x) {
		System.out.println("varargs is called");
	}
	
	//public void add(int...x, String ...y) {}  //not allowed. one method have only one varargs parameter
	
	//public void add(int...x, String y) {} //not allowed. varargs must be the last parameter
	
	public void add( String y, int...x) {}
	


}
