
public class Math {
	public static final double PI = 3.14;

	public void add(int a, int b) {
		System.out.println("add(int a, int b)");
	}

	public void add(int a, int b, int c) {
		System.out.println("add(int a, int b,int c) ");
	}

	public void add(long a, long b) {
		System.out.println("add(long a, long b)");
	}

	public void add(float a, float b) {
		System.out.println("add(long a, long b)");
	}

	public void add(double a, double b) {
		System.out.println("add(double a, double b)");
	}

	public void add(int a, double b) {
		System.out.println("add(int a, double b)");
	}
	
	public double add(double a, int b) {
		System.out.println("add(int a, double b)");
		return 0;
	}
	
	public void foo(int x) {}
	
	
	
	public static void main(String[] args) {
		Math math = new Math();
		math.add(1, 2);
		math.add(2L, 3L);
		math.add(1.2, 2.3);
		math.add(1.2F, 2.3F);
		
		
		math.add(1, 2,3);
	
	}

}
