package pkg2;

public class Employee {
	
	public int id;
	protected String name;
	private double salary;
	double hra;

}
