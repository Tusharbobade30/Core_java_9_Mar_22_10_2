package com.seed.entity;

public class Test {

}
