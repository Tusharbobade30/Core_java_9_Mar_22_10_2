package pkg3;

import pkg1.Employee;
import static pkg1.Employee.idGenerator;
import static java.lang.System.out;


public class Main {
	
	public static void main(String[] args) {
		
		Employee emp = new Employee();
		out.println(emp);
		//System.out.println(Employee.idGenerator);
		
		out.println(idGenerator);
		
		
	}

}


