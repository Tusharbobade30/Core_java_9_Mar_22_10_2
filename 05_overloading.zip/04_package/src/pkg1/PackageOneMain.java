package pkg1;

public class PackageOneMain {
	
	public static void main(String[] args) {
		Employee emp = new Employee();
		System.out.println(emp.id); //public
		System.out.println(emp.name); //protected
		System.out.println(emp.hra); //default
	
	}

}
