pkg1               
Employee 


pkg2
Address


pkg3
Main
Employee
Address       

<br>
<hr>
<h4>Access specifier</h1> 
1. private<br>
2. default /package<br>
3. protected<br>
4. public<br>

class have two access specifier : public and default


pkg1
   10 class
   pkg2
      20 class
      
      
import pkg1.*;
import pkg1.pkg2.*;

<hr>
static import

Package which is default import in a class => java.lang