package com.pkg2;

import com.pkg1.Employee;

public class Manager extends Employee {
	private int noOfSubordinate;

	public Manager() {
		super();
		//System.out.println("Default manager constructor");
	}

	public Manager(int id,String name, double salary, int noOfSubordinate) {
		super(id,name,salary);
		//System.out.println("Paramterized manager constructor");
		this.noOfSubordinate = noOfSubordinate;
	}

	@Override
	public void display() {
		super.display();
		System.out.println("No of sub: "+noOfSubordinate);
	}
	

	@Override
	public double computeNetSalary() {
		return super.computeNetSalary()+ getBonus();
		
	}
	
	//special method
	public double getBonus() {
		return noOfSubordinate*200;
	}

	@Override
	public String toString() {
		return super.toString()+ "   Manager [noOfSubordinate=" + noOfSubordinate + "]";
	}
	
	public void foo() {
		System.out.println("manager class");
	}

	
	
	
 
}
