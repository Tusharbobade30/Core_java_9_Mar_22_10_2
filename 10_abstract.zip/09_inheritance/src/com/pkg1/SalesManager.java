package com.pkg1;

public class SalesManager extends SalesPerson{
	
	private final double FIXED_INCENTIVE = 5000;
	
	public SalesManager() {
		// TODO Auto-generated constructor stub
	}

	public SalesManager(int id, String name, double salary, double sales, double comm) {
		super(id, name, salary, sales, comm);
	}
	
	public double getFIXED_INCENTIVE() {
		return FIXED_INCENTIVE;
	}
	
	@Override
	public double computeNetSalary() {
		// TODO Auto-generated method stub
		return super.computeNetSalary()+FIXED_INCENTIVE;
	}
	

}
