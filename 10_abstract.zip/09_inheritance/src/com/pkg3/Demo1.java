package com.pkg3;

import com.pkg1.Employee;
import com.pkg1.SalesManager;
import com.pkg1.SalesPerson;
import com.pkg2.Manager;

public class Demo1 {

	public static void main(String[] args) {
		display( new Employee(1, "jack", 1000));
		printLine();
		
		display( new Manager(2, "john", 2000, 4));
		printLine();
		
		display( new SalesManager(4, "sam", 4000, 20000, 2));
		printLine();
		
		display( new SalesPerson(3, "jessica", 3000, 10000, 1));
		printLine();
		
	}

	public static void display(Employee emp) {
		System.out.println("display of  employee");
		System.out.println(emp.getClass().getName());
		System.out.println(emp);
		System.out.println("Net salary: " + emp.computeNetSalary());
		
		if(emp instanceof Manager) {
			double bonus = ((Manager)emp).getBonus();
			System.out.println("Bonus: "+bonus);
		}
		
		if(emp instanceof SalesPerson) {
			double Commission = ((SalesPerson)emp).getCommission();
			System.out.println("Commission: "+Commission);
		}
		
	}

	public static void printLine() {
		System.out.println("____________________________________________");
	}

}
