package com.pkg3;

import com.pkg1.Employee;
import com.pkg1.SalesPerson;
import com.pkg2.Manager;

public class Main {

	public static void main(String[] args) {
		exp2();
	}

	public static void exp2() {
		
		Manager m1 = new Manager(2, "Jackie", 5000, 10); // tight coupling

		
		Employee e1 = new Employee(1, "John", 4000);
		Employee e2 = new Manager(3, "Jackie", 5000, 10); // loose coupling
	    Employee e3 =  new SalesPerson();
		
		double bonus =((Manager)e2).getBonus();
		//System.out.println("bonus: "+bonus);
		
		

		// Manager m3 = new Employee(); sub class cannot refer to super class
		
		SalesPerson p1 = new SalesPerson();
		
		displayEmp(e1);
		displayEmp(m1);
		displayEmp(e2);
		displayEmp(p1);
		displayEmp(new Manager());
		
		MyDate dob = new MyDate();
		dob.display();
		
		
	}
	

	public static void displayEmp(Employee emp) {
		System.out.println(emp.getClass().getName());
		System.out.println(emp);
		System.out.println("Net salary: "+emp.computeNetSalary());
		
		if (emp instanceof Manager) {
			double bonus = ((Manager) emp).getBonus();
			System.out.println("bonus: " + bonus);
		}
		
		if(emp instanceof SalesPerson) {
		
		}
		
		emp.display();
		
		printLine();
	}

	public static void exp1() {
		Employee emp = new Employee();
		System.out.println(emp.getClass().getName());
		System.out.println(emp.hashCode());
		printLine();

		Manager mgr1 = new Manager();
		System.out.println(mgr1);
		System.out.println(mgr1.getClass().getName());

		printLine();

		Manager mgr2 = new Manager(1, "John", 5000, 10);
		System.out.println(mgr2);
	}

	public static void printLine() {
		System.out.println("-------------------------------------------------------");
	}

}
