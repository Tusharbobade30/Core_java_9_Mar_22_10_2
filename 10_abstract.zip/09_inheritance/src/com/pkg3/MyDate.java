package com.pkg3;

public class MyDate {
	
	public void display() {}

}
