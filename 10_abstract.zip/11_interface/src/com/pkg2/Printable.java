package com.pkg2;

public interface Printable {
	
	public void print();

}
