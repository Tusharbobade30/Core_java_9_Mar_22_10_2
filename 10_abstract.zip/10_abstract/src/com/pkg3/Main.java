package com.pkg3;

import com.pkg1.Circle;
import com.pkg1.Rectangle;
import com.pkg1.Shape;
import com.pkg1.Square;

public final class Main {

	public static void main(String[] args) {
		//Shape shape = new Shape();
		
		Rectangle rect = new Rectangle(10, 5);
		Circle circle = new Circle(10);
		
		display(rect);
		printLine();
		
		display(circle);
		printLine();
		
		
		display(new Square(5));
		printLine();
		
	}
	
	public static void display(Shape shape) {
		System.out.println(shape);
		System.out.println("Area: "+shape.area());
		System.out.println("Area: "+shape.perimeter());
	}

	public static void printLine() {
		System.out.println("_________________________________________________");
	}
	
}
