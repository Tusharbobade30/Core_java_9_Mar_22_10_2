package com.pkg1;

public class MyDate {
	
	public void display() {}

}
