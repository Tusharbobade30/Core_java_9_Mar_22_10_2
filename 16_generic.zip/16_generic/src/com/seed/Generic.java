package com.seed;

public class Generic<T> {
	
	private T instance;

	public Generic(T instance) {
		this.instance = instance;
	}

	public T getInstance() {
		return instance;
	}

	public void setInstance(T instance) {
		this.instance = instance;
	}
	
}
