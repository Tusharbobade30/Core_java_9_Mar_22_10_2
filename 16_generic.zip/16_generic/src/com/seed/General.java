package com.seed;

public class General {
	
	private Object instance;
	

	public General(Object instance) {
		this.instance = instance;
	}


	public Object getInstance() {
		return instance;
	}


	public void setInstance(Object instance) {
		this.instance = instance;
	}
	
}
