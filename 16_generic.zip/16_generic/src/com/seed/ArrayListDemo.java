package com.seed;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;

public class ArrayListDemo {
	
	public static void main(String[] args) {
		exp3();
	}
	
	public static void exp3() {
		List<Integer> ilist = new ArrayList<Integer>(); 
		ilist.add(1);
		ilist.add(2);
		ilist.add(3);
		
		
		List<Double> dlist = new ArrayList<Double>(); 
		dlist.add(80.0);
		dlist.add(20.0);
		dlist.add(30.0);
		
		List<String> slist = new ArrayList<String>();
		slist.add("java");
		slist.add("spring");
		slist.add("hibernate");
	
		display(ilist);
		display(dlist);
		display(slist);
		
		getAvg(ilist);
		getAvg(dlist);
		//getAvg(slist);
	}
	
	
	//? is called wildcard
	public static void display(List<?> list) {
		for(Object o:list) {
			System.out.println(o);
		}
		System.out.println("------------------------------");
	}
	
	
	public static double getAvg(List<? extends Number> list) {
		double sum=0;
		for(Number n:list) {
			sum = sum +n.doubleValue();
		}
		return sum/list.size();
	}
	
	
	
	
	//sorting
	public static void exp2() {
		List<Integer> iList = new ArrayList<Integer>(); //ordered
		iList.add(80);
		iList.add(20);
		iList.add(30);
		iList.add(180);
		iList.add(2);
		iList.add(300);
		iList.add(20);
		
		System.out.println(iList);
		Collections.sort(iList);
		System.out.println(iList);
		display2(iList);
		
	   boolean test= iList.contains(300);
	   System.out.println(test);
		
	}
	
	public static void display1(List<Integer> list) {
		System.out.println("_____________________________________");
		for(Integer i :list) {
			System.out.println(i);
		}
		System.out.println("--------------------------------------");
	}
	
	public static void display2(List<Integer> list) {
		Iterator<Integer> itr = list.iterator();
		while(itr.hasNext()) {
			Integer i = itr.next();
			System.out.println(i);
		}
	}
	
	
	public static void display3(List<Integer> list) {
		ListIterator<Integer> itr = list.listIterator();
		while(itr.hasNext()) {
			Integer i = itr.next();
			System.out.println(i);
		}
	}
	
	public static void exp1() {
	
		List<Integer> iList = new ArrayList<Integer>(); //ordered
		iList.add(80);
		iList.add(20);
		iList.add(30);
		iList.add(180);
		iList.add(2);
		iList.add(300);
		iList.add(20);
		
		//System.out.println(iList);
		System.out.println(iList.size());
		iList.remove(3);
		//System.out.println(iList);
		
		line();
		
		
		List<Integer> iList1 = new LinkedList<Integer>(); //ordered
		iList1.add(80);
		iList1.add(20);
		iList1.add(30);
		iList1.add(180);
		iList1.add(2);
		iList1.add(300);
		iList1.add(20);
		
		System.out.println(iList1);
		System.out.println(iList1.size());
		iList1.remove(3);

	}
	
	public static void line() {
		System.out.println("-------------------------------------------------");
	}

}
