package com.seed;

import java.util.ArrayList;
import java.util.List;

public class Main {

	public static void main(String[] args) {
		// generalExp1();
		genericExp();
	}
	
	

	public static void generalExp1() {
		General iob = new General(10);
		int i = (Integer) iob.getInstance();
		System.out.println(i);

		General sob = new General("test");
		String s = (String) sob.getInstance();
		System.out.println(s);

		iob = sob;
		i = (Integer) iob.getInstance();
	}

	public static void genericExp() {
		Generic<Integer> iob = new Generic<>(10);
		int i = iob.getInstance();
		// iob.setInstance("hello");
		System.out.println(i);

		Generic<String> sob = new Generic<String>("test");
		String s = sob.getInstance();
		System.out.println(s);
		
		foo(iob);
		foo(sob);
		foo1(iob);
		//foo1(sob); //not allowed Generic<Integer> g = new Generic<String>("test")


	}

	public static void foo(Generic g) {}

	public static void foo1(Generic<Integer> g) {}
	
	public static void foo2(Generic<String> g) {}

}
