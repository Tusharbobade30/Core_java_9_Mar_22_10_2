import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;

public class Client {
	Socket socket;
	DataInputStream dis;
	DataOutputStream dos;
	
	DataInputStream consoleDis;
	
	public Client() {
		try {
			socket = new Socket(InetAddress.getLocalHost(), 2222);
			System.out.println("client object created");
			dos = new DataOutputStream(socket.getOutputStream());
			dis = new DataInputStream(socket.getInputStream());
			consoleDis = new DataInputStream(System.in);
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void chat() throws IOException {
		while(true) {
			String consoleText = consoleDis.readLine();
			dos.writeUTF(consoleText);
			String serverText = dis.readUTF();
			System.out.println("Server: "+serverText);
		}
	}
	
	
	public static void main(String[] args) {
		try {
			new Client().chat();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println("end");
	}

}
