package com.seed;

import java.awt.Color;
import java.awt.Graphics;

import javax.swing.JFrame;

public class MyFrame extends JFrame implements Runnable{
	
	int rx=20;
	int gx=20;
	int bx=20;
	
	public MyFrame() {
		
		this.setVisible(true);
		this.setSize(800,200);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
	}
	
	
	@Override
	public void paint(Graphics g) {
		//super.paint(g);
		
		g.setColor(Color.red);
		g.fillOval(rx, 50, 20, 20);
		
		g.setColor(Color.green);
		g.fillOval(gx, 90, 20, 20);
		
		g.setColor(Color.blue);
		g.fillOval(bx, 130, 20, 20);
		
	}

	@Override
	public void run() {
		try {
			while(true) {
				if(Thread.currentThread().getName().equals("red")) {
					rx++;
					Thread.sleep(40);
					if(rx%200==0) {
						synchronized (this) {
							wait();
						}	
					}
				}
				else if(Thread.currentThread().getName().equals("green")) {
					gx++;
					Thread.sleep(70);
					if(gx%200==0) {
						synchronized (this) {
							wait();
						}	
					}
				}
				else if(Thread.currentThread().getName().equals("blue")) {
					bx++;
					Thread.sleep(100);
					if(bx%200==0) {
						synchronized (this) {
							notifyAll();
						}	
					}
				}
				
				
				
				
				repaint();
				
				
			}
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
	}
	
	
	
	public static void main(String[] args) {
		MyFrame r=new MyFrame();
		
		Thread t1=new Thread(r,"red");
		Thread t2=new Thread(r,"green");
		Thread t3=new Thread(r,"blue");
		
		t1.start();
		t2.start();
		t3.start();
	}

}
